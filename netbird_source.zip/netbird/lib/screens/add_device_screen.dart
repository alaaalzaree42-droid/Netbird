// lib/screens/add_device_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/device.dart';
import '../services/app_provider.dart';
import '../services/ssh_service.dart';
import '../utils/theme.dart';

class AddDeviceScreen extends StatefulWidget {
  final Device? device;
  final String? prefilledIp;
  final String? prefilledType;

  const AddDeviceScreen({
    super.key,
    this.device,
    this.prefilledIp,
    this.prefilledType,
  });

  @override
  State<AddDeviceScreen> createState() => _AddDeviceScreenState();
}

class _AddDeviceScreenState extends State<AddDeviceScreen> {
  final _form = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _ip;
  late final TextEditingController _user;
  late final TextEditingController _pass;
  late final TextEditingController _port;
  String _type = 'litebeam';
  bool _testing = false;
  String? _testResult;
  bool _testSuccess = false;

  final _types = {
    'litebeam': 'LiteBeam',
    'nanostation': 'NanoStation',
    'rocket': 'Rocket',
    'airmax': 'airMAX',
    'unknown': 'Other Ubiquiti',
  };

  @override
  void initState() {
    super.initState();
    final d = widget.device;
    _name = TextEditingController(text: d?.name ?? '');
    _ip = TextEditingController(
        text: d?.ip ?? widget.prefilledIp ?? '');
    _user = TextEditingController(text: d?.username ?? 'ubnt');
    _pass = TextEditingController(text: d?.password ?? '');
    _port = TextEditingController(text: '${d?.port ?? 22}');
    _type = widget.prefilledType ?? d?.type ?? 'litebeam';
  }

  @override
  void dispose() {
    _name.dispose();
    _ip.dispose();
    _user.dispose();
    _pass.dispose();
    _port.dispose();
    super.dispose();
  }

  Future<void> _testConnection() async {
    setState(() {
      _testing = true;
      _testResult = null;
    });
    try {
      final tmpDevice = Device(
        id: 'test',
        name: 'test',
        ip: _ip.text.trim(),
        username: _user.text.trim(),
        password: _pass.text,
        port: int.tryParse(_port.text) ?? 22,
      );
      await SSHService.runCommand(tmpDevice, 'echo ok');
      SSHService.disconnect('test');
      setState(() {
        _testResult = '✓ Connected successfully';
        _testSuccess = true;
      });
    } catch (e) {
      setState(() {
        _testResult = '✗ ${e.toString()}';
        _testSuccess = false;
      });
    }
    setState(() => _testing = false);
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    final provider = context.read<AppProvider>();
    final isEdit = widget.device != null;

    if (isEdit) {
      final updated = widget.device!.copyWith(
        name: _name.text.trim(),
        ip: _ip.text.trim(),
        username: _user.text.trim(),
        password: _pass.text,
        port: int.tryParse(_port.text) ?? 22,
        type: _type,
      );
      await provider.updateDevice(updated);
    } else {
      final d = provider.createDevice(
        name: _name.text.trim().isEmpty ? _ip.text.trim() : _name.text.trim(),
        ip: _ip.text.trim(),
        username: _user.text.trim(),
        password: _pass.text,
        port: int.tryParse(_port.text) ?? 22,
        type: _type,
      );
      await provider.addDevice(d);
    }
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        title: Text(widget.device != null ? 'Edit Device' : 'Add Device'),
        actions: [
          TextButton(
            onPressed: _save,
            child: const Text('Save',
                style: TextStyle(
                    color: AppTheme.accent, fontWeight: FontWeight.w600)),
          ),
        ],
      ),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // ── Device Type ──
            _sectionLabel('DEVICE TYPE'),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: _types.entries.map((e) {
                final selected = _type == e.key;
                return GestureDetector(
                  onTap: () => setState(() => _type = e.key),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: selected
                          ? AppTheme.accent.withOpacity(0.15)
                          : AppTheme.card,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                          color: selected
                              ? AppTheme.accent
                              : AppTheme.border),
                    ),
                    child: Text(e.value,
                        style: TextStyle(
                            color: selected
                                ? AppTheme.accent
                                : AppTheme.textSecondary,
                            fontSize: 13,
                            fontWeight: selected
                                ? FontWeight.w600
                                : FontWeight.normal)),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),

            // ── Basic Info ──
            _sectionLabel('DEVICE INFO'),
            _field(_name, 'Name', hint: 'e.g. Tower-North'),
            const SizedBox(height: 10),
            _field(_ip, 'IP Address',
                hint: '192.168.1.100',
                keyboard: TextInputType.numberWithOptions(decimal: true),
                validator: (v) =>
                    v!.isEmpty ? 'Required' : null,
                mono: true),
            const SizedBox(height: 20),

            // ── Credentials ──
            _sectionLabel('SSH CREDENTIALS'),
            _field(_user, 'Username', hint: 'ubnt'),
            const SizedBox(height: 10),
            _passField(),
            const SizedBox(height: 10),
            SizedBox(
              width: 100,
              child: _field(_port, 'Port',
                  hint: '22',
                  keyboard: TextInputType.number,
                  mono: true),
            ),
            const SizedBox(height: 20),

            // ── Test Connection ──
            OutlinedButton.icon(
              icon: _testing
                  ? const SizedBox(
                      width: 14,
                      height: 14,
                      child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor:
                              AlwaysStoppedAnimation(AppTheme.accent)))
                  : const Icon(Icons.cable, size: 16),
              label: Text(_testing ? 'Testing...' : 'Test Connection'),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppTheme.accent,
                side: const BorderSide(color: AppTheme.accent),
              ),
              onPressed: _testing ||
                      _ip.text.isEmpty ||
                      _user.text.isEmpty ||
                      _pass.text.isEmpty
                  ? null
                  : _testConnection,
            ),
            if (_testResult != null) ...[
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: (_testSuccess ? AppTheme.success : AppTheme.danger)
                      .withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                      color: (_testSuccess ? AppTheme.success : AppTheme.danger)
                          .withOpacity(0.4)),
                ),
                child: Text(
                  _testResult!,
                  style: TextStyle(
                      color: _testSuccess ? AppTheme.success : AppTheme.danger,
                      fontSize: 13,
                      fontFamily: 'monospace'),
                ),
              ),
            ],
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: _save,
              child: Text(widget.device != null ? 'Save Changes' : 'Add Device'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionLabel(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Text(text,
            style: const TextStyle(
                color: AppTheme.textMuted,
                fontSize: 11,
                fontWeight: FontWeight.w600,
                letterSpacing: 1.1)),
      );

  Widget _field(
    TextEditingController ctrl,
    String label, {
    String? hint,
    TextInputType? keyboard,
    String? Function(String?)? validator,
    bool mono = false,
  }) =>
      TextFormField(
        controller: ctrl,
        keyboardType: keyboard,
        style: TextStyle(
          color: AppTheme.textPrimary,
          fontFamily: mono ? 'monospace' : null,
          fontSize: 14,
        ),
        validator: validator,
        decoration: InputDecoration(labelText: label, hintText: hint),
      );

  Widget _passField() {
    bool show = false;
    return StatefulBuilder(
      builder: (_, setSt) => TextFormField(
        controller: _pass,
        obscureText: !show,
        style: const TextStyle(color: AppTheme.textPrimary, fontSize: 14),
        decoration: InputDecoration(
          labelText: 'Password',
          suffixIcon: IconButton(
            icon: Icon(show ? Icons.visibility_off : Icons.visibility,
                size: 18, color: AppTheme.textMuted),
            onPressed: () => setSt(() => show = !show),
          ),
        ),
      ),
    );
  }
}
