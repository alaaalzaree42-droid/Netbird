// lib/screens/home_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/device.dart';
import '../services/app_provider.dart';
import '../utils/theme.dart';
import '../widgets/common.dart';
import 'device_dashboard_screen.dart';
import 'scanner_screen.dart';
import 'add_device_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<AppProvider>().loadDevices();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              width: 28,
              height: 28,
              decoration: BoxDecoration(
                color: AppTheme.accent.withOpacity(0.15),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: AppTheme.accent.withOpacity(0.4)),
              ),
              child: const Icon(Icons.wifi, size: 16, color: AppTheme.accent),
            ),
            const SizedBox(width: 10),
            const Text('NetBird'),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search, size: 20),
            tooltip: 'Scan Network',
            onPressed: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => const ScannerScreen())),
          ),
          IconButton(
            icon: const Icon(Icons.add, size: 22),
            tooltip: 'Add Device',
            onPressed: () => _showAddDevice(context),
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: Consumer<AppProvider>(
        builder: (context, provider, _) {
          if (provider.loading) {
            return const Center(
                child: CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation(AppTheme.accent)));
          }

          if (provider.devices.isEmpty) {
            return _buildEmpty(context);
          }

          return RefreshIndicator(
            color: AppTheme.accent,
            backgroundColor: AppTheme.card,
            onRefresh: provider.loadDevices,
            child: ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: provider.devices.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, i) =>
                  _DeviceCard(device: provider.devices[i]),
            ),
          );
        },
      ),
    );
  }

  Widget _buildEmpty(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.device_hub, size: 56, color: AppTheme.textMuted),
          const SizedBox(height: 16),
          const Text('No devices yet',
              style: TextStyle(color: AppTheme.textSecondary, fontSize: 16)),
          const SizedBox(height: 6),
          const Text('Scan your network or add manually',
              style: TextStyle(color: AppTheme.textMuted, fontSize: 13)),
          const SizedBox(height: 24),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              ElevatedButton.icon(
                icon: const Icon(Icons.search, size: 16),
                label: const Text('Scan Network'),
                onPressed: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const ScannerScreen())),
              ),
              const SizedBox(width: 10),
              OutlinedButton.icon(
                icon: const Icon(Icons.add, size: 16, color: AppTheme.textSecondary),
                label: const Text('Add Manual',
                    style: TextStyle(color: AppTheme.textSecondary)),
                style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: AppTheme.border)),
                onPressed: () => _showAddDevice(context),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _showAddDevice(BuildContext context) {
    Navigator.push(
        context, MaterialPageRoute(builder: (_) => const AddDeviceScreen()));
  }
}

// ─── Device Card ─────────────────────────────────────────────────────────
class _DeviceCard extends StatelessWidget {
  final Device device;
  const _DeviceCard({required this.device});

  @override
  Widget build(BuildContext context) {
    final stats = device.lastStats;
    return GestureDetector(
      onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
              builder: (_) => DeviceDashboardScreen(device: device))),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppTheme.card,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: device.isOnline
                ? AppTheme.success.withOpacity(0.3)
                : AppTheme.border,
          ),
        ),
        child: Row(
          children: [
            // Icon
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: AppTheme.bg,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppTheme.border),
              ),
              child: Center(child: DeviceTypeIcon(type: device.type, size: 22)),
            ),
            const SizedBox(width: 12),
            // Info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(device.name,
                      style: const TextStyle(
                          color: AppTheme.textPrimary,
                          fontSize: 14,
                          fontWeight: FontWeight.w600)),
                  const SizedBox(height: 3),
                  Text(device.ip,
                      style: const TextStyle(
                          color: AppTheme.textMuted,
                          fontSize: 12,
                          fontFamily: 'monospace')),
                  if (stats != null) ...[
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        SignalBars(dbm: stats.signalStrength),
                        const SizedBox(width: 8),
                        Text('${stats.signalStrength.toStringAsFixed(0)} dBm',
                            style: TextStyle(
                                color: AppTheme.signalColor(stats.signalStrength),
                                fontSize: 11)),
                        const SizedBox(width: 12),
                        Text('CCQ ${stats.ccq.toStringAsFixed(0)}%',
                            style: const TextStyle(
                                color: AppTheme.textSecondary, fontSize: 11)),
                      ],
                    ),
                  ],
                ],
              ),
            ),
            // Status
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                StatusBadge(online: device.isOnline),
                if (device.lastSeen != null) ...[
                  const SizedBox(height: 6),
                  Text(
                    _timeAgo(device.lastSeen!),
                    style: const TextStyle(
                        color: AppTheme.textMuted, fontSize: 10),
                  ),
                ],
                const SizedBox(height: 6),
                const Icon(Icons.chevron_right,
                    size: 16, color: AppTheme.textMuted),
              ],
            ),
          ],
        ),
      ),
    );
  }

  String _timeAgo(DateTime t) {
    final diff = DateTime.now().difference(t);
    if (diff.inMinutes < 1) return 'just now';
    if (diff.inHours < 1) return '${diff.inMinutes}m ago';
    if (diff.inDays < 1) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }
}
