// lib/screens/device_dashboard_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import '../models/device.dart';
import '../services/app_provider.dart';
import '../services/ssh_service.dart';
import '../utils/theme.dart';
import '../widgets/common.dart';
import 'terminal_screen.dart';
import 'add_device_screen.dart';
import 'channel_scan_screen.dart';

class DeviceDashboardScreen extends StatefulWidget {
  final Device device;
  const DeviceDashboardScreen({super.key, required this.device});
  @override
  State<DeviceDashboardScreen> createState() => _DeviceDashboardScreenState();
}

class _DeviceDashboardScreenState extends State<DeviceDashboardScreen> {
  bool _refreshing = false;
  late Device _device;

  @override
  void initState() {
    super.initState();
    _device = widget.device;
    _refresh();
  }

  Future<void> _refresh() async {
    setState(() => _refreshing = true);
    final provider = context.read<AppProvider>();
    final stats = await provider.refreshStats(_device);
    // reload updated device
    final updated = provider.devices.firstWhere((d) => d.id == _device.id,
        orElse: () => _device);
    if (mounted) setState(() {
      _device = updated.copyWith(lastStats: stats);
      _refreshing = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final stats = _device.lastStats;
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(_device.name,
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
            Text(_device.ip,
                style: const TextStyle(
                    fontSize: 11,
                    color: AppTheme.textMuted,
                    fontFamily: 'monospace')),
          ],
        ),
        actions: [
          StatusBadge(online: _device.isOnline),
          const SizedBox(width: 8),
          IconButton(
            icon: _refreshing
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation(AppTheme.accent)))
                : const Icon(Icons.refresh, size: 20),
            onPressed: _refreshing ? null : _refresh,
          ),
          PopupMenuButton(
            icon: const Icon(Icons.more_vert, size: 20),
            color: AppTheme.card,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            itemBuilder: (_) => [
              _menuItem(Icons.edit_outlined, 'Edit Device', 'edit'),
              _menuItem(Icons.terminal, 'SSH Terminal', 'terminal'),
              _menuItem(Icons.delete_outline, 'Delete', 'delete',
                  color: AppTheme.danger),
            ],
            onSelected: (v) => _handleMenu(v as String, context),
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: RefreshIndicator(
        color: AppTheme.accent,
        backgroundColor: AppTheme.card,
        onRefresh: _refresh,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // ── Signal Stats ──
            if (stats != null) ...[
              SectionHeader(title: 'SIGNAL'),
              GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: 8,
                mainAxisSpacing: 8,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                childAspectRatio: 1.7,
                children: [
                  StatCard(
                    label: 'SIGNAL',
                    value: '${stats.signalStrength.toStringAsFixed(0)} dBm',
                    valueColor: AppTheme.signalColor(stats.signalStrength),
                    icon: Icons.signal_cellular_alt,
                    trailing: SignalBars(dbm: stats.signalStrength),
                  ),
                  StatCard(
                    label: 'NOISE FLOOR',
                    value: '${stats.noiseFloor.toStringAsFixed(0)} dBm',
                    valueColor: AppTheme.textSecondary,
                    icon: Icons.graphic_eq,
                  ),
                  StatCard(
                    label: 'SNR',
                    value: '${stats.snr.toStringAsFixed(0)} dB',
                    valueColor: AppTheme.qualityColor(stats.snr * 2),
                    icon: Icons.show_chart,
                  ),
                  StatCard(
                    label: 'CCQ',
                    value: '${stats.ccq.toStringAsFixed(0)}%',
                    valueColor: AppTheme.qualityColor(stats.ccq),
                    icon: Icons.speed,
                  ),
                ],
              ),
              const SizedBox(height: 8),
              GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: 8,
                mainAxisSpacing: 8,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                childAspectRatio: 1.7,
                children: [
                  StatCard(
                    label: 'TX RATE',
                    value: '${stats.txRate.toStringAsFixed(0)} Mbps',
                    icon: Icons.upload,
                  ),
                  StatCard(
                    label: 'RX RATE',
                    value: '${stats.rxRate.toStringAsFixed(0)} Mbps',
                    icon: Icons.download,
                  ),
                  StatCard(
                    label: 'UPTIME',
                    value: stats.uptimeFormatted,
                    icon: Icons.timer_outlined,
                  ),
                  StatCard(
                    label: 'CLIENTS',
                    value: '${stats.connectedClients}',
                    icon: Icons.people_outline,
                  ),
                ],
              ),
              if (stats.frequency.isNotEmpty || stats.model.isNotEmpty) ...[
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppTheme.card,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppTheme.border),
                  ),
                  child: Row(
                    children: [
                      if (stats.model.isNotEmpty)
                        _infoChip('MODEL', stats.model),
                      if (stats.frequency.isNotEmpty)
                        _infoChip('FREQ', '${stats.frequency} MHz'),
                      if (stats.firmware.isNotEmpty)
                        _infoChip('FW', stats.firmware),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: 4),
            ] else if (!_device.isOnline) ...[
              _offlineCard(),
            ],

            // ── Quick Actions ──
            SectionHeader(title: 'QUICK ACTIONS'),
            _QuickActions(device: _device, onRefresh: _refresh),

            // ── Custom Commands ──
            SectionHeader(
              title: 'CUSTOM COMMANDS',
              action: IconButton(
                icon: const Icon(Icons.add, size: 18, color: AppTheme.accent),
                onPressed: () => _showAddCommand(context),
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
              ),
            ),
            _CustomCommandsList(device: _device),

            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  Widget _infoChip(String label, String value) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: const TextStyle(
                  color: AppTheme.textMuted, fontSize: 10, letterSpacing: 0.8)),
          const SizedBox(height: 3),
          Text(value,
              style: const TextStyle(
                  color: AppTheme.textPrimary,
                  fontSize: 12,
                  fontFamily: 'monospace')),
        ],
      ),
    );
  }

  Widget _offlineCard() {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.danger.withOpacity(0.08),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppTheme.danger.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          const Icon(Icons.wifi_off, color: AppTheme.danger, size: 20),
          const SizedBox(width: 10),
          const Expanded(
            child: Text('Device is offline or unreachable',
                style: TextStyle(color: AppTheme.danger, fontSize: 13)),
          ),
          TextButton(
            onPressed: _refresh,
            child: const Text('Retry'),
          ),
        ],
      ),
    );
  }

  PopupMenuItem _menuItem(IconData icon, String label, String value,
      {Color? color}) {
    return PopupMenuItem(
      value: value,
      child: Row(
        children: [
          Icon(icon, size: 16, color: color ?? AppTheme.textSecondary),
          const SizedBox(width: 10),
          Text(label,
              style: TextStyle(
                  color: color ?? AppTheme.textPrimary, fontSize: 14)),
        ],
      ),
    );
  }

  void _handleMenu(String action, BuildContext context) {
    switch (action) {
      case 'edit':
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (_) => AddDeviceScreen(device: _device)));
        break;
      case 'terminal':
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (_) => TerminalScreen(device: _device)));
        break;
      case 'delete':
        _confirmDelete(context);
        break;
    }
  }

  void _confirmDelete(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.card,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: const Text('Delete Device',
            style: TextStyle(color: AppTheme.textPrimary)),
        content: Text('Remove "${_device.name}" from devices?',
            style: const TextStyle(color: AppTheme.textSecondary)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.danger),
            onPressed: () async {
              await context.read<AppProvider>().deleteDevice(_device.id);
              if (mounted) {
                Navigator.pop(context); // close dialog
                Navigator.pop(context); // back to home
              }
            },
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _showAddCommand(BuildContext context) {
    final nameCtrl = TextEditingController();
    final cmdCtrl = TextEditingController();
    String icon = '⚡';
    final icons = ['⚡', '🔄', '📊', '🔍', '🛠', '📡', '🔒', '📋'];

    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.card,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (_) => StatefulBuilder(
        builder: (ctx, setSt) => Padding(
          padding: EdgeInsets.only(
              bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
              left: 16,
              right: 16,
              top: 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Add Custom Command',
                  style: TextStyle(
                      color: AppTheme.textPrimary,
                      fontSize: 16,
                      fontWeight: FontWeight.w600)),
              const SizedBox(height: 16),
              Wrap(
                spacing: 8,
                children: icons.map((ic) => GestureDetector(
                  onTap: () => setSt(() => icon = ic),
                  child: Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: icon == ic
                          ? AppTheme.accent.withOpacity(0.2)
                          : AppTheme.bg,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                          color: icon == ic
                              ? AppTheme.accent
                              : AppTheme.border),
                    ),
                    child: Center(child: Text(ic, style: const TextStyle(fontSize: 18))),
                  ),
                )).toList(),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: nameCtrl,
                style: const TextStyle(color: AppTheme.textPrimary),
                decoration: const InputDecoration(labelText: 'Command Name'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: cmdCtrl,
                style: const TextStyle(
                    color: AppTheme.success, fontFamily: 'monospace', fontSize: 13),
                decoration: const InputDecoration(
                    labelText: 'Shell Command',
                    hintText: 'e.g. cat /proc/net/arp'),
                maxLines: 3,
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    if (nameCtrl.text.isEmpty || cmdCtrl.text.isEmpty) return;
                    final cmd = CustomCommand(
                      id: const Uuid().v4(),
                      name: nameCtrl.text,
                      command: cmdCtrl.text,
                      icon: icon,
                    );
                    context.read<AppProvider>().addCustomCommand(_device, cmd);
                    setState(() => _device.customCommands.add(cmd));
                    Navigator.pop(context);
                  },
                  child: const Text('Add Command'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Quick Actions Widget ──────────────────────────────────────────────────
class _QuickActions extends StatefulWidget {
  final Device device;
  final VoidCallback onRefresh;
  const _QuickActions({required this.device, required this.onRefresh});
  @override
  State<_QuickActions> createState() => _QuickActionsState();
}

class _QuickActionsState extends State<_QuickActions> {
  bool _rebooting = false;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        _actionBtn(
          icon: Icons.refresh,
          label: _rebooting ? 'Rebooting...' : 'Reboot',
          color: AppTheme.danger,
          onTap: _rebooting ? null : _reboot,
        ),
        _actionBtn(
          icon: Icons.wifi_find,
          label: 'Channel Scan',
          color: AppTheme.accent,
          onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (_) =>
                      ChannelScanScreen(device: widget.device))),
        ),
        _actionBtn(
          icon: Icons.terminal,
          label: 'Terminal',
          color: AppTheme.textSecondary,
          onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (_) => TerminalScreen(device: widget.device))),
        ),
        _actionBtn(
          icon: Icons.info_outline,
          label: 'System Info',
          color: AppTheme.textSecondary,
          onTap: _showSystemInfo,
        ),
      ],
    );
  }

  Widget _actionBtn({
    required IconData icon,
    required String label,
    required Color color,
    VoidCallback? onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color.withOpacity(0.35)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 15, color: color),
            const SizedBox(width: 6),
            Text(label,
                style: TextStyle(
                    color: color, fontSize: 13, fontWeight: FontWeight.w500)),
          ],
        ),
      ),
    );
  }

  Future<void> _reboot() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: const Text('Confirm Reboot',
            style: TextStyle(color: AppTheme.textPrimary)),
        content: Text('Reboot ${widget.device.name}?',
            style: const TextStyle(color: AppTheme.textSecondary)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.danger),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Reboot'),
          ),
        ],
      ),
    );

    if (confirm != true) return;
    setState(() => _rebooting = true);
    try {
      await SSHService.reboot(widget.device);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Reboot command sent successfully'),
          backgroundColor: AppTheme.success,
        ));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Error: $e'),
          backgroundColor: AppTheme.danger,
        ));
      }
    }
    if (mounted) setState(() => _rebooting = false);
  }

  Future<void> _showSystemInfo() async {
    showDialog(
      context: context,
      builder: (_) => const AlertDialog(
        backgroundColor: AppTheme.card,
        content: SizedBox(
          height: 60,
          child: Center(
              child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation(AppTheme.accent))),
        ),
      ),
    );
    try {
      final info = await SSHService.getSystemInfo(widget.device);
      if (mounted) {
        Navigator.pop(context); // close loading
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            backgroundColor: AppTheme.card,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            title: const Text('System Info',
                style: TextStyle(color: AppTheme.textPrimary, fontSize: 15)),
            content: SingleChildScrollView(child: TerminalOutput(text: info)),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Close')),
            ],
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Error: $e'),
          backgroundColor: AppTheme.danger,
        ));
      }
    }
  }
}

// ─── Custom Commands List ──────────────────────────────────────────────────
class _CustomCommandsList extends StatefulWidget {
  final Device device;
  const _CustomCommandsList({required this.device});
  @override
  State<_CustomCommandsList> createState() => _CustomCommandsListState();
}

class _CustomCommandsListState extends State<_CustomCommandsList> {
  final Map<String, bool> _running = {};
  final Map<String, String> _results = {};

  @override
  Widget build(BuildContext context) {
    if (widget.device.customCommands.isEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Text('No custom commands. Tap + to add one.',
            style: TextStyle(color: AppTheme.textMuted, fontSize: 12)),
      );
    }

    return Column(
      children: widget.device.customCommands.map((cmd) {
        final running = _running[cmd.id] ?? false;
        final result = _results[cmd.id];
        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          decoration: BoxDecoration(
            color: AppTheme.card,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppTheme.border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ListTile(
                dense: true,
                leading: Text(cmd.icon, style: const TextStyle(fontSize: 20)),
                title: Text(cmd.name,
                    style: const TextStyle(
                        color: AppTheme.textPrimary, fontSize: 13)),
                subtitle: Text(cmd.command,
                    style: const TextStyle(
                        color: AppTheme.textMuted,
                        fontSize: 11,
                        fontFamily: 'monospace')),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    running
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                                strokeWidth: 2,
                                valueColor:
                                    AlwaysStoppedAnimation(AppTheme.accent)))
                        : IconButton(
                            icon: const Icon(Icons.play_arrow,
                                size: 20, color: AppTheme.accent),
                            onPressed: () => _runCmd(cmd),
                          ),
                    IconButton(
                      icon: const Icon(Icons.delete_outline,
                          size: 18, color: AppTheme.textMuted),
                      onPressed: () {
                        context
                            .read<AppProvider>()
                            .removeCustomCommand(widget.device, cmd.id);
                        setState(() {});
                      },
                    ),
                  ],
                ),
              ),
              if (result != null)
                Padding(
                  padding:
                      const EdgeInsets.only(left: 12, right: 12, bottom: 12),
                  child: TerminalOutput(text: result),
                ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Future<void> _runCmd(CustomCommand cmd) async {
    setState(() => _running[cmd.id] = true);
    try {
      final out = await SSHService.runCommand(widget.device, cmd.command);
      setState(() => _results[cmd.id] = out);
    } catch (e) {
      setState(() => _results[cmd.id] = 'Error: $e');
    }
    setState(() => _running[cmd.id] = false);
  }
}
