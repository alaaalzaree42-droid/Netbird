// lib/screens/terminal_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/device.dart';
import '../services/ssh_service.dart';
import '../utils/theme.dart';

class TerminalScreen extends StatefulWidget {
  final Device device;
  const TerminalScreen({super.key, required this.device});
  @override
  State<TerminalScreen> createState() => _TerminalScreenState();
}

class _TerminalScreenState extends State<TerminalScreen> {
  final _cmdCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  final List<_TermLine> _lines = [];
  bool _busy = false;
  final List<String> _history = [];
  int _histIdx = -1;

  final _quickCmds = [
    ('status', 'mca-status'),
    ('uptime', 'uptime'),
    ('ifconfig', 'ifconfig'),
    ('route', 'route -n'),
    ('log', 'tail -20 /var/log/messages'),
    ('proc', 'cat /proc/loadavg'),
  ];

  @override
  void initState() {
    super.initState();
    _addLine('> Connected to ${widget.device.ip}', AppTheme.accent);
    _addLine('> Type commands below', AppTheme.textMuted);
  }

  @override
  void dispose() {
    _cmdCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  void _addLine(String text, Color color) {
    setState(() =>
        _lines.add(_TermLine(text: text, color: color, time: DateTime.now())));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _run(String cmd) async {
    cmd = cmd.trim();
    if (cmd.isEmpty) return;
    _history.insert(0, cmd);
    _histIdx = -1;
    _cmdCtrl.clear();
    _addLine('\$ $cmd', AppTheme.success);
    setState(() => _busy = true);
    try {
      final out = await SSHService.runCommand(widget.device, cmd);
      _addLine(out.isEmpty ? '(no output)' : out, AppTheme.textPrimary);
    } catch (e) {
      _addLine('Error: $e', AppTheme.danger);
    }
    setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E13),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0A0E13),
        title: Row(
          children: [
            const Icon(Icons.terminal, size: 16, color: AppTheme.success),
            const SizedBox(width: 8),
            Text(widget.device.name,
                style: const TextStyle(fontSize: 14, fontFamily: 'monospace')),
            const SizedBox(width: 8),
            Text('@${widget.device.ip}',
                style: const TextStyle(
                    fontSize: 12,
                    color: AppTheme.textMuted,
                    fontFamily: 'monospace')),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_sweep, size: 18),
            tooltip: 'Clear',
            onPressed: () => setState(() => _lines.clear()),
          ),
          IconButton(
            icon: const Icon(Icons.copy, size: 18),
            tooltip: 'Copy all',
            onPressed: () {
              Clipboard.setData(
                  ClipboardData(text: _lines.map((l) => l.text).join('\n')));
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                    content: Text('Copied to clipboard'),
                    duration: Duration(seconds: 1)),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Quick commands
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(
              children: _quickCmds.map((q) {
                return GestureDetector(
                  onTap: () => _run(q.$2),
                  child: Container(
                    margin: const EdgeInsets.only(right: 6),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: AppTheme.surface,
                      borderRadius: BorderRadius.circular(5),
                      border: Border.all(color: AppTheme.border),
                    ),
                    child: Text(q.$1,
                        style: const TextStyle(
                            color: AppTheme.accent,
                            fontSize: 12,
                            fontFamily: 'monospace')),
                  ),
                );
              }).toList(),
            ),
          ),
          const Divider(height: 1, color: AppTheme.border),

          // Output
          Expanded(
            child: SelectionArea(
              child: ListView.builder(
                controller: _scrollCtrl,
                padding: const EdgeInsets.all(12),
                itemCount: _lines.length,
                itemBuilder: (_, i) {
                  final line = _lines[i];
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 2),
                    child: Text(
                      line.text,
                      style: TextStyle(
                        color: line.color,
                        fontFamily: 'monospace',
                        fontSize: 12.5,
                        height: 1.5,
                      ),
                    ),
                  );
                },
              ),
            ),
          ),

          // Input
          Container(
            decoration: const BoxDecoration(
              color: AppTheme.surface,
              border: Border(top: BorderSide(color: AppTheme.border)),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(
              children: [
                const Text('\$ ',
                    style: TextStyle(
                        color: AppTheme.success,
                        fontFamily: 'monospace',
                        fontSize: 16,
                        fontWeight: FontWeight.bold)),
                Expanded(
                  child: TextField(
                    controller: _cmdCtrl,
                    enabled: !_busy,
                    autofocus: true,
                    style: const TextStyle(
                        color: AppTheme.textPrimary,
                        fontFamily: 'monospace',
                        fontSize: 13),
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      hintText: 'Enter command...',
                      hintStyle: TextStyle(
                          color: AppTheme.textMuted, fontFamily: 'monospace'),
                      isDense: true,
                      contentPadding: EdgeInsets.zero,
                    ),
                    onSubmitted: _run,
                    onChanged: (_) => setState(() => _histIdx = -1),
                  ),
                ),
                // History navigation
                if (_history.isNotEmpty) ...[
                  IconButton(
                    icon: const Icon(Icons.keyboard_arrow_up, size: 18),
                    color: AppTheme.textMuted,
                    onPressed: () {
                      if (_histIdx < _history.length - 1) {
                        setState(() {
                          _histIdx++;
                          _cmdCtrl.text = _history[_histIdx];
                        });
                      }
                    },
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                  ),
                  const SizedBox(width: 4),
                ],
                _busy
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor:
                                AlwaysStoppedAnimation(AppTheme.accent)))
                    : IconButton(
                        icon: const Icon(Icons.send, size: 18),
                        color: AppTheme.accent,
                        onPressed: () => _run(_cmdCtrl.text),
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(),
                      ),
              ],
            ),
          ),
          SizedBox(height: MediaQuery.of(context).viewInsets.bottom),
        ],
      ),
    );
  }
}

class _TermLine {
  final String text;
  final Color color;
  final DateTime time;
  _TermLine({required this.text, required this.color, required this.time});
}
