// lib/screens/channel_scan_screen.dart
import 'package:flutter/material.dart';
import '../models/device.dart';
import '../services/ssh_service.dart';
import '../utils/theme.dart';
import '../widgets/common.dart';

class ChannelScanScreen extends StatefulWidget {
  final Device device;
  const ChannelScanScreen({super.key, required this.device});
  @override
  State<ChannelScanScreen> createState() => _ChannelScanScreenState();
}

class _ChannelScanScreenState extends State<ChannelScanScreen> {
  bool _scanning = false;
  String _raw = '';
  List<_ChannelEntry> _channels = [];

  @override
  void initState() {
    super.initState();
    _scan();
  }

  Future<void> _scan() async {
    setState(() {
      _scanning = true;
      _raw = '';
      _channels = [];
    });
    try {
      final raw = await SSHService.scanChannels(widget.device);
      setState(() {
        _raw = raw;
        _channels = _parse(raw);
        _scanning = false;
      });
    } catch (e) {
      setState(() {
        _raw = 'Error: $e';
        _scanning = false;
      });
    }
  }

  List<_ChannelEntry> _parse(String raw) {
    final entries = <_ChannelEntry>[];
    String? currentEssid;
    int? currentChannel;
    double? currentSignal;

    for (final line in raw.split('\n')) {
      final trimmed = line.trim();
      if (trimmed.contains('ESSID:')) {
        currentEssid =
            trimmed.replaceAll('ESSID:', '').replaceAll('"', '').trim();
      } else if (trimmed.contains('Channel:')) {
        currentChannel = int.tryParse(
            trimmed.replaceAll('Channel:', '').trim().split(' ').first);
      } else if (trimmed.contains('Signal level=')) {
        final match =
            RegExp(r'Signal level=(-?\d+)').firstMatch(trimmed);
        if (match != null) {
          currentSignal = double.tryParse(match.group(1)!);
        }
        if (currentChannel != null) {
          entries.add(_ChannelEntry(
            essid: currentEssid ?? 'Hidden',
            channel: currentChannel,
            signal: currentSignal ?? -100,
          ));
          currentEssid = null;
          currentChannel = null;
          currentSignal = null;
        }
      }
    }

    entries.sort((a, b) => b.signal.compareTo(a.signal));
    return entries;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        title: const Text('Channel Scan'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, size: 20),
            onPressed: _scanning ? null : _scan,
          ),
        ],
      ),
      body: _scanning
          ? const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation(AppTheme.accent)),
                  SizedBox(height: 16),
                  Text('Scanning channels...',
                      style: TextStyle(color: AppTheme.textSecondary)),
                  SizedBox(height: 6),
                  Text('This may take 30-60 seconds',
                      style:
                          TextStyle(color: AppTheme.textMuted, fontSize: 12)),
                ],
              ),
            )
          : _channels.isEmpty
              ? Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SectionHeader(title: 'RAW OUTPUT'),
                      TerminalOutput(text: _raw),
                    ],
                  ),
                )
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    // Summary
                    _buildChannelUsage(),
                    const SizedBox(height: 16),
                    SectionHeader(
                        title: 'DETECTED NETWORKS (${_channels.length})'),
                    ..._channels.map((c) => _ChannelCard(entry: c)),
                    const SizedBox(height: 16),
                    const SectionHeader(title: 'RAW OUTPUT'),
                    TerminalOutput(text: _raw),
                  ],
                ),
    );
  }

  Widget _buildChannelUsage() {
    // Count networks per channel
    final usage = <int, int>{};
    for (final c in _channels) {
      usage[c.channel] = (usage[c.channel] ?? 0) + 1;
    }

    // Find least congested
    final sorted = usage.entries.toList()..sort((a, b) => a.value.compareTo(b.value));
    final best = sorted.isNotEmpty ? sorted.first.key : null;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.analytics_outlined, size: 14, color: AppTheme.accent),
              SizedBox(width: 6),
              Text('CHANNEL ANALYSIS',
                  style: TextStyle(
                      color: AppTheme.textSecondary,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.8)),
            ],
          ),
          const SizedBox(height: 12),
          if (best != null) ...[
            Row(
              children: [
                const Text('Best Channel:',
                    style: TextStyle(
                        color: AppTheme.textSecondary, fontSize: 13)),
                const SizedBox(width: 8),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppTheme.success.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(6),
                    border:
                        Border.all(color: AppTheme.success.withOpacity(0.4)),
                  ),
                  child: Text('Ch $best (${usage[best]} networks)',
                      style: const TextStyle(
                          color: AppTheme.success,
                          fontSize: 13,
                          fontWeight: FontWeight.w600)),
                ),
              ],
            ),
            const SizedBox(height: 10),
          ],
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: usage.entries.map((e) {
              final isBest = e.key == best;
              return Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: isBest
                      ? AppTheme.success.withOpacity(0.1)
                      : AppTheme.bg,
                  borderRadius: BorderRadius.circular(5),
                  border: Border.all(
                      color: isBest
                          ? AppTheme.success.withOpacity(0.4)
                          : AppTheme.border),
                ),
                child: Text('Ch ${e.key}: ${e.value}',
                    style: TextStyle(
                        color: isBest
                            ? AppTheme.success
                            : AppTheme.textSecondary,
                        fontSize: 12,
                        fontFamily: 'monospace')),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}

class _ChannelEntry {
  final String essid;
  final int channel;
  final double signal;
  _ChannelEntry({required this.essid, required this.channel, required this.signal});
}

class _ChannelCard extends StatelessWidget {
  final _ChannelEntry entry;
  const _ChannelCard({required this.entry});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppTheme.border),
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: AppTheme.bg,
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: AppTheme.border),
            ),
            child: Center(
              child: Text('${entry.channel}',
                  style: const TextStyle(
                      color: AppTheme.accent,
                      fontFamily: 'monospace',
                      fontWeight: FontWeight.w700)),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(entry.essid,
                    style: const TextStyle(
                        color: AppTheme.textPrimary,
                        fontSize: 13)),
                const SizedBox(height: 2),
                Text('${entry.signal.toStringAsFixed(0)} dBm',
                    style: TextStyle(
                        color: AppTheme.signalColor(entry.signal),
                        fontSize: 12,
                        fontFamily: 'monospace')),
              ],
            ),
          ),
          SignalBars(dbm: entry.signal),
        ],
      ),
    );
  }
}
