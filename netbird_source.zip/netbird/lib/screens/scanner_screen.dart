// lib/screens/scanner_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/device.dart';
import '../services/scanner_service.dart';
import '../services/app_provider.dart';
import '../utils/theme.dart';
import '../widgets/common.dart';
import 'add_device_screen.dart';

class ScannerScreen extends StatefulWidget {
  const ScannerScreen({super.key});
  @override
  State<ScannerScreen> createState() => _ScannerScreenState();
}

class _ScannerScreenState extends State<ScannerScreen> {
  final _rangeCtrl = TextEditingController(text: '192.168.1.1-254');
  final _portCtrl = TextEditingController(text: '22');
  bool _scanning = false;
  final List<ScannedHost> _results = [];
  int _scanned = 0;
  int _total = 0;

  @override
  void dispose() {
    ScannerService.stopScan();
    _rangeCtrl.dispose();
    _portCtrl.dispose();
    super.dispose();
  }

  Future<void> _startScan() async {
    setState(() {
      _scanning = true;
      _results.clear();
      _scanned = 0;
    });

    final range = _rangeCtrl.text.trim();
    final port = int.tryParse(_portCtrl.text) ?? 22;

    // Calculate total
    _total = _estimateTotal(range);

    await for (final host in ScannerService.scanRange(range, sshPort: port)) {
      if (!mounted) break;
      setState(() {
        _scanned++;
        if (host.isAlive) _results.add(host);
      });
    }

    if (mounted) setState(() => _scanning = false);
  }

  int _estimateTotal(String range) {
    if (range.contains('-')) {
      final parts = range.split('-');
      final start = int.tryParse(parts[0].split('.').last) ?? 1;
      final end = int.tryParse(parts[1]) ?? 254;
      return end - start + 1;
    }
    if (range.contains('/24')) return 254;
    return 1;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        title: const Text('Network Scanner'),
        actions: [
          if (_scanning)
            TextButton(
              onPressed: () {
                ScannerService.stopScan();
                setState(() => _scanning = false);
              },
              child: const Text('Stop',
                  style: TextStyle(color: AppTheme.danger)),
            ),
        ],
      ),
      body: Column(
        children: [
          // ── Scan Config ──
          Container(
            padding: const EdgeInsets.all(16),
            decoration: const BoxDecoration(
              color: AppTheme.surface,
              border: Border(bottom: BorderSide(color: AppTheme.border)),
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: TextField(
                        controller: _rangeCtrl,
                        enabled: !_scanning,
                        style: const TextStyle(
                            color: AppTheme.textPrimary,
                            fontFamily: 'monospace',
                            fontSize: 13),
                        decoration: const InputDecoration(
                          labelText: 'IP Range',
                          hintText: '192.168.1.1-254',
                          prefixIcon: Icon(Icons.lan, size: 16,
                              color: AppTheme.textMuted),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    SizedBox(
                      width: 80,
                      child: TextField(
                        controller: _portCtrl,
                        enabled: !_scanning,
                        keyboardType: TextInputType.number,
                        style: const TextStyle(
                            color: AppTheme.textPrimary,
                            fontFamily: 'monospace'),
                        decoration: const InputDecoration(labelText: 'Port'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: _scanning
                          ? Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                LinearProgressIndicator(
                                  value: _total > 0 ? _scanned / _total : null,
                                  backgroundColor: AppTheme.border,
                                  valueColor: const AlwaysStoppedAnimation(
                                      AppTheme.accent),
                                  borderRadius: BorderRadius.circular(4),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  '$_scanned / $_total  •  ${_results.length} found',
                                  style: const TextStyle(
                                      color: AppTheme.textMuted, fontSize: 11),
                                ),
                              ],
                            )
                          : Text(
                              _scanned > 0
                                  ? 'Found ${_results.length} of $_scanned hosts'
                                  : 'Enter range and tap Scan',
                              style: const TextStyle(
                                  color: AppTheme.textMuted, fontSize: 12),
                            ),
                    ),
                    const SizedBox(width: 12),
                    ElevatedButton.icon(
                      icon: Icon(
                          _scanning ? Icons.stop : Icons.search, size: 16),
                      label: Text(_scanning ? 'Scanning...' : 'Scan'),
                      onPressed: _scanning ? null : _startScan,
                    ),
                  ],
                ),
              ],
            ),
          ),

          // ── Results ──
          Expanded(
            child: _results.isEmpty
                ? Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.wifi_find,
                            size: 48, color: AppTheme.textMuted),
                        const SizedBox(height: 12),
                        Text(
                          _scanning
                              ? 'Scanning $_scanned / $_total...'
                              : 'No results yet',
                          style: const TextStyle(
                              color: AppTheme.textSecondary, fontSize: 14),
                        ),
                      ],
                    ),
                  )
                : ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: _results.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (context, i) =>
                        _HostCard(host: _results[i]),
                  ),
          ),
        ],
      ),
    );
  }
}

class _HostCard extends StatelessWidget {
  final ScannedHost host;
  const _HostCard({required this.host});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: host.isUbiquiti
              ? AppTheme.accent.withOpacity(0.4)
              : AppTheme.border,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: host.isUbiquiti
                  ? AppTheme.accent.withOpacity(0.1)
                  : AppTheme.bg,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                  color: host.isUbiquiti
                      ? AppTheme.accent.withOpacity(0.4)
                      : AppTheme.border),
            ),
            child: Icon(
              host.isUbiquiti ? Icons.settings_input_antenna : Icons.device_hub,
              size: 18,
              color: host.isUbiquiti ? AppTheme.accent : AppTheme.textMuted,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(host.ip,
                        style: const TextStyle(
                            color: AppTheme.textPrimary,
                            fontFamily: 'monospace',
                            fontSize: 14,
                            fontWeight: FontWeight.w600)),
                    if (host.isUbiquiti) ...[
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: AppTheme.accent.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: const Text('UBIQUITI',
                            style: TextStyle(
                                color: AppTheme.accent,
                                fontSize: 9,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 0.8)),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 3),
                Row(
                  children: [
                    if (host.hostname != null && host.hostname != host.ip)
                      Text(host.hostname!,
                          style: const TextStyle(
                              color: AppTheme.textMuted, fontSize: 11)),
                    if (host.hasSSH) ...[
                      if (host.hostname != null) const SizedBox(width: 8),
                      const Icon(Icons.terminal,
                          size: 11, color: AppTheme.success),
                      const SizedBox(width: 3),
                      const Text('SSH',
                          style: TextStyle(
                              color: AppTheme.success, fontSize: 11)),
                    ],
                  ],
                ),
              ],
            ),
          ),
          // Add button
          OutlinedButton(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (_) => AddDeviceScreen(
                        prefilledIp: host.ip,
                        prefilledType: host.isUbiquiti ? 'litebeam' : 'unknown',
                      )),
            ),
            style: OutlinedButton.styleFrom(
              side: const BorderSide(color: AppTheme.border),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              minimumSize: Size.zero,
            ),
            child: const Text('Add',
                style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 12,
                    fontWeight: FontWeight.w500)),
          ),
        ],
      ),
    );
  }
}
