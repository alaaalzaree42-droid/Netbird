// lib/models/device.dart

class Device {
  final String id;
  String name;
  String ip;
  String username;
  String password;
  int port;
  String type; // litebeam, nanostation, rocket, unknown
  bool isOnline;
  DateTime? lastSeen;
  DeviceStats? lastStats;
  List<CustomCommand> customCommands;

  Device({
    required this.id,
    required this.name,
    required this.ip,
    required this.username,
    required this.password,
    this.port = 22,
    this.type = 'unknown',
    this.isOnline = false,
    this.lastSeen,
    this.lastStats,
    this.customCommands = const [],
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'ip': ip,
        'username': username,
        'password': password,
        'port': port,
        'type': type,
        'isOnline': isOnline ? 1 : 0,
        'lastSeen': lastSeen?.toIso8601String(),
      };

  factory Device.fromMap(Map<String, dynamic> map) => Device(
        id: map['id'],
        name: map['name'],
        ip: map['ip'],
        username: map['username'],
        password: map['password'],
        port: map['port'] ?? 22,
        type: map['type'] ?? 'unknown',
        isOnline: map['isOnline'] == 1,
        lastSeen: map['lastSeen'] != null ? DateTime.parse(map['lastSeen']) : null,
      );

  Device copyWith({
    String? name,
    String? ip,
    String? username,
    String? password,
    int? port,
    String? type,
    bool? isOnline,
    DateTime? lastSeen,
    DeviceStats? lastStats,
    List<CustomCommand>? customCommands,
  }) =>
      Device(
        id: id,
        name: name ?? this.name,
        ip: ip ?? this.ip,
        username: username ?? this.username,
        password: password ?? this.password,
        port: port ?? this.port,
        type: type ?? this.type,
        isOnline: isOnline ?? this.isOnline,
        lastSeen: lastSeen ?? this.lastSeen,
        lastStats: lastStats ?? this.lastStats,
        customCommands: customCommands ?? this.customCommands,
      );
}

class DeviceStats {
  final double signalStrength; // dBm
  final double noiseFloor;
  final double ccq; // Connection quality %
  final String frequency;
  final String channel;
  final double txRate;
  final double rxRate;
  final int uptime; // seconds
  final String firmware;
  final String model;
  final int connectedClients;

  DeviceStats({
    this.signalStrength = 0,
    this.noiseFloor = 0,
    this.ccq = 0,
    this.frequency = '',
    this.channel = '',
    this.txRate = 0,
    this.rxRate = 0,
    this.uptime = 0,
    this.firmware = '',
    this.model = '',
    this.connectedClients = 0,
  });

  String get uptimeFormatted {
    final d = Duration(seconds: uptime);
    if (d.inDays > 0) return '${d.inDays}d ${d.inHours.remainder(24)}h';
    if (d.inHours > 0) return '${d.inHours}h ${d.inMinutes.remainder(60)}m';
    return '${d.inMinutes}m';
  }

  double get snr => signalStrength - noiseFloor;

  String get signalQuality {
    if (signalStrength >= -60) return 'Excellent';
    if (signalStrength >= -70) return 'Good';
    if (signalStrength >= -80) return 'Fair';
    return 'Poor';
  }
}

class CustomCommand {
  final String id;
  String name;
  String command;
  String icon;

  CustomCommand({
    required this.id,
    required this.name,
    required this.command,
    this.icon = '⚡',
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'command': command,
        'icon': icon,
      };

  factory CustomCommand.fromMap(Map<String, dynamic> map) => CustomCommand(
        id: map['id'],
        name: map['name'],
        command: map['command'],
        icon: map['icon'] ?? '⚡',
      );
}

class ScannedHost {
  final String ip;
  final bool isAlive;
  final bool hasSSH;
  final bool isUbiquiti;
  final String? hostname;

  ScannedHost({
    required this.ip,
    required this.isAlive,
    this.hasSSH = false,
    this.isUbiquiti = false,
    this.hostname,
  });
}
