// lib/services/app_provider.dart
import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';
import '../models/device.dart';
import 'database_service.dart';
import 'ssh_service.dart';

class AppProvider extends ChangeNotifier {
  List<Device> _devices = [];
  bool _loading = false;
  String? _error;

  List<Device> get devices => _devices;
  bool get loading => _loading;
  String? get error => _error;

  final _uuid = const Uuid();

  Future<void> loadDevices() async {
    _loading = true;
    notifyListeners();
    try {
      _devices = await DatabaseService.getDevices();
    } catch (e) {
      _error = e.toString();
    }
    _loading = false;
    notifyListeners();
  }

  Future<void> addDevice(Device device) async {
    await DatabaseService.saveDevice(device);
    _devices.add(device);
    notifyListeners();
  }

  Future<void> updateDevice(Device device) async {
    await DatabaseService.updateDevice(device);
    final idx = _devices.indexWhere((d) => d.id == device.id);
    if (idx >= 0) _devices[idx] = device;
    notifyListeners();
  }

  Future<void> deleteDevice(String id) async {
    await DatabaseService.deleteDevice(id);
    _devices.removeWhere((d) => d.id == id);
    SSHService.disconnect(id);
    notifyListeners();
  }

  Future<DeviceStats?> refreshStats(Device device) async {
    try {
      final stats = await SSHService.fetchStats(device);
      final updated = device.copyWith(
        lastStats: stats,
        isOnline: true,
        lastSeen: DateTime.now(),
      );
      await updateDevice(updated);
      return stats;
    } catch (_) {
      final updated = device.copyWith(isOnline: false);
      await updateDevice(updated);
      return null;
    }
  }

  Device createDevice({
    required String name,
    required String ip,
    required String username,
    required String password,
    int port = 22,
    String type = 'unknown',
  }) =>
      Device(
        id: _uuid.v4(),
        name: name,
        ip: ip,
        username: username,
        password: password,
        port: port,
        type: type,
      );

  void addCustomCommand(Device device, CustomCommand cmd) {
    device.customCommands.add(cmd);
    updateDevice(device);
  }

  void removeCustomCommand(Device device, String cmdId) {
    device.customCommands.removeWhere((c) => c.id == cmdId);
    updateDevice(device);
  }

  String newId() => _uuid.v4();
}
