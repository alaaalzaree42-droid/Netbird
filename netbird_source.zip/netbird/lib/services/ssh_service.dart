// lib/services/ssh_service.dart
import 'package:dartssh2/dartssh2.dart';
import 'dart:async';
import '../models/device.dart';

class SSHService {
  static final Map<String, SSHClient> _clients = {};

  // ─── Connect ───────────────────────────────────────────────
  static Future<SSHClient> connect(Device device) async {
    if (_clients.containsKey(device.id)) {
      return _clients[device.id]!;
    }

    final socket = await SSHSocket.connect(device.ip, device.port,
        timeout: const Duration(seconds: 8));

    final client = SSHClient(
      socket,
      username: device.username,
      onPasswordRequest: () => device.password,
    );

    await client.authenticated;
    _clients[device.id] = client;
    return client;
  }

  // ─── Run Command ───────────────────────────────────────────
  static Future<String> runCommand(Device device, String command) async {
    try {
      final client = await connect(device);
      final session = await client.execute(command);
      final output = await session.stdout.transform(const SystemEncoding().decoder).join();
      await session.done;
      return output.trim();
    } catch (e) {
      _clients.remove(device.id);
      rethrow;
    }
  }

  // ─── Disconnect ────────────────────────────────────────────
  static void disconnect(String deviceId) {
    _clients[deviceId]?.close();
    _clients.remove(deviceId);
  }

  static void disconnectAll() {
    for (final c in _clients.values) {
      c.close();
    }
    _clients.clear();
  }

  // ─── Ubiquiti Stats Parser ─────────────────────────────────
  static Future<DeviceStats?> fetchStats(Device device) async {
    try {
      // Use mca-status which is standard on AirOS devices
      final raw = await runCommand(device, 'mca-status');
      return _parseMcaStatus(raw);
    } catch (_) {
      try {
        // Fallback: try ubntbox
        final raw = await runCommand(device, 'iwconfig ath0 2>/dev/null || iwconfig wlan0 2>/dev/null');
        return _parseIwconfig(raw);
      } catch (_) {
        return null;
      }
    }
  }

  static DeviceStats _parseMcaStatus(String raw) {
    double signal = 0, noise = 0, ccq = 0, txRate = 0, rxRate = 0;
    String freq = '', channel = '', firmware = '', model = '';
    int uptime = 0, clients = 0;

    for (final line in raw.split('\n')) {
      final parts = line.split('=');
      if (parts.length < 2) continue;
      final key = parts[0].trim();
      final val = parts[1].trim();

      switch (key) {
        case 'signal':
          signal = double.tryParse(val) ?? 0;
          break;
        case 'noisef':
          noise = double.tryParse(val) ?? 0;
          break;
        case 'ccq':
          ccq = (double.tryParse(val) ?? 0) / 10;
          break;
        case 'freq':
          freq = val;
          break;
        case 'chwidth':
          channel = val;
          break;
        case 'tx_rate':
          txRate = (double.tryParse(val) ?? 0) / 1000;
          break;
        case 'rx_rate':
          rxRate = (double.tryParse(val) ?? 0) / 1000;
          break;
        case 'uptime':
          uptime = int.tryParse(val) ?? 0;
          break;
        case 'firmwareVersion':
          firmware = val;
          break;
        case 'platform':
          model = val;
          break;
        case 'stacnt':
          clients = int.tryParse(val) ?? 0;
          break;
      }
    }

    return DeviceStats(
      signalStrength: signal,
      noiseFloor: noise,
      ccq: ccq,
      frequency: freq,
      channel: channel,
      txRate: txRate,
      rxRate: rxRate,
      uptime: uptime,
      firmware: firmware,
      model: model,
      connectedClients: clients,
    );
  }

  static DeviceStats _parseIwconfig(String raw) {
    double signal = 0, noise = 0;
    final signalMatch = RegExp(r'Signal level[=:](-?\d+)').firstMatch(raw);
    final noiseMatch = RegExp(r'Noise level[=:](-?\d+)').firstMatch(raw);
    if (signalMatch != null) signal = double.tryParse(signalMatch.group(1)!) ?? 0;
    if (noiseMatch != null) noise = double.tryParse(noiseMatch.group(1)!) ?? 0;
    return DeviceStats(signalStrength: signal, noiseFloor: noise);
  }

  // ─── Ubiquiti Specific Commands ────────────────────────────

  static Future<String> reboot(Device device) async {
    await runCommand(device, 'reboot');
    disconnect(device.id);
    return 'Reboot command sent';
  }

  static Future<String> scanChannels(Device device) async {
    // AirOS channel scan
    final result = await runCommand(
        device, 'iwlist ath0 scanning 2>/dev/null | grep -E "Channel|Signal|ESSID" | head -60');
    return result.isEmpty ? 'No scan results' : result;
  }

  static Future<String> getBestChannel(Device device) async {
    final result = await runCommand(device,
        r"iwlist ath0 scanning 2>/dev/null | awk '/Channel:/{ch=\$0} /Signal level=/{print ch, \$0}' | sort -t= -k2 -n | head -10");
    return result.isEmpty ? 'Could not determine best channel' : result;
  }

  static Future<String> getArpTable(Device device) async {
    return runCommand(device, 'arp -a');
  }

  static Future<String> getSystemInfo(Device device) async {
    return runCommand(device, 'cat /etc/version; uptime; free; df -h /');
  }

  // ─── Ping Test ─────────────────────────────────────────────
  static Future<bool> pingSSH(String ip, int port, {int timeoutSec = 5}) async {
    try {
      final socket = await SSHSocket.connect(ip, port,
          timeout: Duration(seconds: timeoutSec));
      socket.destroy();
      return true;
    } catch (_) {
      return false;
    }
  }
}
