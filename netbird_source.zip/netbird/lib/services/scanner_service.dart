// lib/services/scanner_service.dart
import 'dart:async';
import 'dart:io';
import '../models/device.dart';
import 'ssh_service.dart';

class ScannerService {
  static bool _scanning = false;
  static bool get isScanning => _scanning;

  /// Scan an IP range like "192.168.1.1-254" or "192.168.1.0/24"
  static Stream<ScannedHost> scanRange(
    String range, {
    int sshPort = 22,
    int concurrency = 30,
  }) async* {
    _scanning = true;
    final ips = _parseRange(range);
    final controller = StreamController<ScannedHost>();
    int completed = 0;

    // Process in parallel batches
    for (int i = 0; i < ips.length; i += concurrency) {
      if (!_scanning) break;
      final batch = ips.skip(i).take(concurrency).toList();

      final futures = batch.map((ip) async {
        final host = await _probeHost(ip, sshPort);
        controller.add(host);
        completed++;
        if (completed >= ips.length) controller.close();
        return host;
      });

      await Future.wait(futures);
      yield* controller.stream.take(batch.length);
    }

    _scanning = false;
  }

  static void stopScan() => _scanning = false;

  static Future<ScannedHost> _probeHost(String ip, int sshPort) async {
    // Step 1: TCP ping to SSH port
    bool hasSSH = false;
    bool isUbiquiti = false;
    String? hostname;

    try {
      final sock = await Socket.connect(ip, sshPort,
          timeout: const Duration(seconds: 2));
      hasSSH = true;

      // Read SSH banner to detect Ubiquiti
      final banner = await sock.first.timeout(const Duration(seconds: 2),
          onTimeout: () => []);
      final bannerStr = String.fromCharCodes(banner);
      if (bannerStr.toLowerCase().contains('ubnt') ||
          bannerStr.toLowerCase().contains('dropbear') ||
          bannerStr.contains('SSH-2.0-OpenSSH')) {
        isUbiquiti = bannerStr.toLowerCase().contains('ubnt');
      }
      sock.destroy();
    } catch (_) {}

    // Step 2: Try reverse DNS
    try {
      final result = await InternetAddress(ip).reverse().timeout(
            const Duration(seconds: 1),
          );
      hostname = result.host;
    } catch (_) {}

    // Step 3: If SSH open, try to confirm Ubiquiti via SSH fingerprint
    if (hasSSH && !isUbiquiti) {
      isUbiquiti = await _checkUbiquiti(ip, sshPort);
    }

    return ScannedHost(
      ip: ip,
      isAlive: hasSSH,
      hasSSH: hasSSH,
      isUbiquiti: isUbiquiti,
      hostname: hostname,
    );
  }

  static Future<bool> _checkUbiquiti(String ip, int port) async {
    try {
      // Quick auth attempt to see ubiquiti fingerprint
      final result = await SSHService.pingSSH(ip, port, timeoutSec: 3);
      return result;
    } catch (_) {
      return false;
    }
  }

  /// Parse range formats: "192.168.1.1-254", "192.168.1.0/24", "192.168.1.1"
  static List<String> _parseRange(String range) {
    range = range.trim();

    // CIDR: 192.168.1.0/24
    if (range.contains('/')) {
      final parts = range.split('/');
      final prefix = parts[0].split('.');
      final mask = int.tryParse(parts[1]) ?? 24;
      if (mask >= 24) {
        final base = prefix.take(3).join('.');
        return List.generate(254, (i) => '$base.${i + 1}');
      }
    }

    // Range: 192.168.1.1-254
    if (range.contains('-')) {
      final dashIdx = range.lastIndexOf('-');
      final baseIp = range.substring(0, range.lastIndexOf('.') + 1);
      final startStr = range.substring(range.lastIndexOf('.') + 1, dashIdx);
      final endStr = range.substring(dashIdx + 1);
      final start = int.tryParse(startStr) ?? 1;
      final end = int.tryParse(endStr) ?? 254;
      return List.generate(end - start + 1, (i) => '$baseIp${start + i}');
    }

    // Single IP
    return [range];
  }
}
