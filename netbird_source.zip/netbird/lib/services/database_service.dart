// lib/services/database_service.dart
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'dart:convert';
import '../models/device.dart';

class DatabaseService {
  static Database? _db;

  static Future<Database> get db async {
    _db ??= await _initDb();
    return _db!;
  }

  static Future<Database> _initDb() async {
    final path = join(await getDatabasesPath(), 'netbird.db');
    return openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE devices (
            id TEXT PRIMARY KEY,
            name TEXT,
            ip TEXT,
            username TEXT,
            password TEXT,
            port INTEGER DEFAULT 22,
            type TEXT DEFAULT 'unknown',
            isOnline INTEGER DEFAULT 0,
            lastSeen TEXT,
            customCommands TEXT DEFAULT '[]'
          )
        ''');
      },
    );
  }

  // ─── Devices ───────────────────────────────────────────────
  static Future<List<Device>> getDevices() async {
    final d = await db;
    final rows = await d.query('devices', orderBy: 'name ASC');
    return rows.map((r) {
      final dev = Device.fromMap(r);
      final cmds = jsonDecode(r['customCommands'] as String? ?? '[]') as List;
      dev.customCommands = cmds.map((c) => CustomCommand.fromMap(c as Map<String, dynamic>)).toList();
      return dev;
    }).toList();
  }

  static Future<void> saveDevice(Device device) async {
    final d = await db;
    final map = device.toMap();
    map['customCommands'] = jsonEncode(device.customCommands.map((c) => c.toMap()).toList());
    await d.insert('devices', map, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  static Future<void> updateDevice(Device device) async {
    final d = await db;
    final map = device.toMap();
    map['customCommands'] = jsonEncode(device.customCommands.map((c) => c.toMap()).toList());
    await d.update('devices', map, where: 'id = ?', whereArgs: [device.id]);
  }

  static Future<void> deleteDevice(String id) async {
    final d = await db;
    await d.delete('devices', where: 'id = ?', whereArgs: [id]);
  }
}
