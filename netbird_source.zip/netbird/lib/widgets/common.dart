// lib/widgets/common.dart
import 'package:flutter/material.dart';
import '../utils/theme.dart';

// ─── Stat Card ─────────────────────────────────────────────────────────────
class StatCard extends StatelessWidget {
  final String label;
  final String value;
  final Color? valueColor;
  final IconData? icon;
  final Widget? trailing;

  const StatCard({
    super.key,
    required this.label,
    required this.value,
    this.valueColor,
    this.icon,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              if (icon != null) ...[
                Icon(icon, size: 13, color: AppTheme.textMuted),
                const SizedBox(width: 5),
              ],
              Text(label,
                  style: const TextStyle(
                      color: AppTheme.textSecondary, fontSize: 11)),
              if (trailing != null) ...[
                const Spacer(),
                trailing!,
              ],
            ],
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(
              color: valueColor ?? AppTheme.textPrimary,
              fontSize: 20,
              fontWeight: FontWeight.w700,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Signal Bar ────────────────────────────────────────────────────────────
class SignalBars extends StatelessWidget {
  final double dbm;
  const SignalBars({super.key, required this.dbm});

  int get _bars {
    if (dbm >= -60) return 4;
    if (dbm >= -70) return 3;
    if (dbm >= -80) return 2;
    return 1;
  }

  @override
  Widget build(BuildContext context) {
    final color = AppTheme.signalColor(dbm);
    return Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: List.generate(4, (i) {
        final active = i < _bars;
        return Container(
          width: 4,
          height: 6.0 + i * 3,
          margin: const EdgeInsets.only(right: 2),
          decoration: BoxDecoration(
            color: active ? color : AppTheme.border,
            borderRadius: BorderRadius.circular(1),
          ),
        );
      }),
    );
  }
}

// ─── Status Badge ──────────────────────────────────────────────────────────
class StatusBadge extends StatelessWidget {
  final bool online;
  const StatusBadge({super.key, required this.online});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: (online ? AppTheme.success : AppTheme.danger).withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: (online ? AppTheme.success : AppTheme.danger).withOpacity(0.4),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(
              color: online ? AppTheme.success : AppTheme.danger,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 5),
          Text(
            online ? 'Online' : 'Offline',
            style: TextStyle(
              color: online ? AppTheme.success : AppTheme.danger,
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Device Type Icon ──────────────────────────────────────────────────────
class DeviceTypeIcon extends StatelessWidget {
  final String type;
  final double size;
  const DeviceTypeIcon({super.key, required this.type, this.size = 28});

  @override
  Widget build(BuildContext context) {
    IconData icon;
    switch (type.toLowerCase()) {
      case 'litebeam':
        icon = Icons.settings_input_antenna;
        break;
      case 'nanostation':
        icon = Icons.router;
        break;
      case 'rocket':
        icon = Icons.wifi_tethering;
        break;
      default:
        icon = Icons.device_hub;
    }
    return Icon(icon, size: size, color: AppTheme.accent);
  }
}

// ─── Section Header ────────────────────────────────────────────────────────
class SectionHeader extends StatelessWidget {
  final String title;
  final Widget? action;
  const SectionHeader({super.key, required this.title, this.action});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          Text(title,
              style: const TextStyle(
                color: AppTheme.textSecondary,
                fontSize: 11,
                fontWeight: FontWeight.w600,
                letterSpacing: 1.2,
              )),
          const Expanded(
              child: Divider(
                  indent: 10, color: AppTheme.border, thickness: 1)),
          if (action != null) action!,
        ],
      ),
    );
  }
}

// ─── Loading Overlay ───────────────────────────────────────────────────────
class LoadingOverlay extends StatelessWidget {
  final String message;
  const LoadingOverlay({super.key, this.message = 'Loading...'});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppTheme.bg.withOpacity(0.85),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation(AppTheme.accent)),
            const SizedBox(height: 16),
            Text(message,
                style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
          ],
        ),
      ),
    );
  }
}

// ─── Terminal Output ───────────────────────────────────────────────────────
class TerminalOutput extends StatelessWidget {
  final String text;
  const TerminalOutput({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF0A0E13),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppTheme.border),
      ),
      child: SelectableText(
        text.isEmpty ? '— no output —' : text,
        style: const TextStyle(
          fontFamily: 'monospace',
          fontSize: 12,
          color: Color(0xFF7EE787),
          height: 1.6,
        ),
      ),
    );
  }
}
